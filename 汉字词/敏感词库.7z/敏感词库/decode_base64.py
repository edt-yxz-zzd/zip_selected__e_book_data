from base64 import b64decode
import sys


def decode_to(ifname, ofname):
    with open(ofname, 'xb') as fout:
        decode(ifname, fout)
def decode(ifname, binary_fout):
    with open(ifname, 'rb') as fin:
        bs = fin.read()
        for line in bs.split():
            s = b64decode(line)
            binary_fout.write(s)

#decode('pub_banned_words.txt', sys.stdout.buffer)
#decode_to('pub_banned_words.txt', 'pub_banned_words.decoded.txt')
decode_to('pub_sms_banned_words.txt', 'pub_sms_banned_words.decoded.txt')




