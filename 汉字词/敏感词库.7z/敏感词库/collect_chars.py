
from glob import iglob

fname_pattern = r'./敏感词库/**/*.txt'

def collect_chars_from_fobj(fin, *, output=None):
    if output is None:
        output = set()
    for line in fin:
        output.update(line)
    return output

encodings = ('gb18030', 'utf8')
s = set()
for fname in iglob(fname_pattern, recursive=True):
    print(fname)
    output = set()
    for encoding in encodings:
        try:
            with open(fname, encoding=encoding) as fin:
                collect_chars_from_fobj(fin, output = output)
        except:
            continue
        else:
            print(encoding)
            s |= output
            break

def std_chars(s):
    return ''.join(sorted(set(s)))
s = std_chars(s)
#print(s)
with open('chars_in_banned_words.u8', 'x', encoding = 'utf8') as fout:
    fout.write(s)




